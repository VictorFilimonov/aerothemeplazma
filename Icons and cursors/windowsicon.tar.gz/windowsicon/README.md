# Windows 8 Icons

![image.com](http://images.all-free-download.com/images/graphicthumb/folder_37125.jpg)

Windows 8 icon theme. although not differing much from Windows 7's icons, this icon theme has some exclusive icons differing it from Windows 7

**Maintainer:** [feren](https://github.com/feren)

**Original license:** GPL v3, by [Ambiance-69](https://www.gnome-look.org/member/336792/)
