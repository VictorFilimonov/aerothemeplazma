sudo mv application-x-bzip application-x-bzip.png
sudo mv application-x-gzip application-x-gzip.png
sudo mv application-zip application-zip.png

